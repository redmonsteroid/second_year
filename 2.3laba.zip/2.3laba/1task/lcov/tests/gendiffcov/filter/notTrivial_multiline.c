void y(int x, int z) {
  ; // maybe this should be
  /* marked trivial but two semicolons found */ ;
}
