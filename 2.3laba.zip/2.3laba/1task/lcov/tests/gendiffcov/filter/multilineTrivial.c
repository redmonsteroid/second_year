void x() {
  // comment
  /* and another comment
     which goes to here */}
