coreToBlaze_fxp(sr_sig_nor, ((0 << 16) | ((nf_len * symb_num) & 0xFFFF)), 15);
