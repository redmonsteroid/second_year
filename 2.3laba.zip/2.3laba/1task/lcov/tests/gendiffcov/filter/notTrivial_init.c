Data::Data(int a)
:  Base(a) {
}
