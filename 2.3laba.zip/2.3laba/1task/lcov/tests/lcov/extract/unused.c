/* this code is not linked into the exe/not called.
   Testing 'initial' capture and combined capture */
#include <stdio.h>

void f(int y)
{
  if (y)
    printf("y == %d\n", y);
}
